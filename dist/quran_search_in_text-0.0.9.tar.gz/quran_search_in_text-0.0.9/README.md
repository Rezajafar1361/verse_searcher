Each paragraph of the text is examined separately and if there is a verse in it, it is observed
The location of the verse along with the address of the verse in the Quran is presented in a list in the output
Also, the input text can be converted into an HTML text in which the verses of the Qur'an are placed in their own tag and have a title, as well as a link to the Qur'an page on the relevant site.
Input can be text or a list of texts

The source code is available at the following address:
https://github.com/Rezajafar1361/oder_project.git